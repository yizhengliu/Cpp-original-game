#include "header.h"
#include "Town_state.h"
#include "ExplorerEngine.h"
#include "Pause_menu.h"
#include "Enemy.h"
#include "Gameend.h"
#include "Charactordatas.h"
#include <cmath>

void Town_state::initialize() {
	//load
	for (int i = 0; i < 15; i++)
		for (int j = 0; j < 7; j++) {
			town.setMapValue(i, j,eng_for_print->townmap[j][i]);
		}
	town.setTopLeftPositionOnScreen(0, 0);
	town.drawAllTiles(this->eng_for_print, this->eng_for_print->getBackgroundSurface());
	eng_for_print->player->initilize();
	show_player();
}

void Town_state::show_player() {
	eng_for_print->setAllObjectsVisible(true);
}

void Town_state::unshow_player() {
	eng_for_print->setAllObjectsVisible(false);
}

void Town_state::key_pressed(int iKeycode) {
	if (iKeycode == SDLK_ESCAPE) {
		SimpleImage image = ImageManager::loadImage("images/pause_bg.jpg", false);
		image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
			0, 0,
			eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
			0, 0,
			image.getWidth(), image.getHeight(), false);
		context_->TransitionTo(new Pause_menu(this->eng_for_print));
	}
}

void Town_state::print_foreground(){
	eng_for_print->drawForegroundString(20, 20, "Hp:", 0x000000, eng_for_print->getFont("Myfont.ttf", 20));
	eng_for_print->drawForegroundString(20, 50, "Mp:", 0x000000, eng_for_print->getFont("Myfont.ttf", 20));
	eng_for_print->drawForegroundRectangle(
		60, 20,
		60 + (eng_for_print->player->gethp()*2), 40,
		0xff0000
	);

	eng_for_print->drawForegroundRectangle(
		60, 50,
		60 + (eng_for_print->player->getmp()*2), 70,
		0x0000ff
	);
	
	eng_for_print->drawForegroundString(600, 650, ("Score: " + std::to_string(eng_for_print->player->getscore())).c_str(),
		0x000000, eng_for_print->getFont("Myfont.ttf", 20));
}

void Town_state::mouse_pressed(int iButton, int iX, int iY){
	if (iButton == SDL_BUTTON_LEFT) {
		eng_for_print->player->shoot(eng_for_print,
			eng_for_print->player->midpointX(),
			eng_for_print->player->midpointY(),
			iX,iY);
	}
}

void Town_state::do_before_loop(){
	for (Enemy* e : eng_for_print->enemys) {
		for (Bullet* b : eng_for_print->bullets) {
			if (e->Perfect_Collision_detection(b,b->getTheta(),1)) {
				e->dead = true;
				b->done = true;
				eng_for_print->removeDisplayableObject(e);
				eng_for_print->removeDisplayableObject(b);
				eng_for_print->player->incscore();
			}
		}
		

		if (e->Perfect_Collision_detection(eng_for_print->player)) {
			eng_for_print->player->enemy_encounte(e->state);
		}

		{
			int iTileX = town.getMapXForScreenX(e->getmidpointX());
			int iTileY = town.getMapYForScreenY(e->getmidpointY());
			int iCurrentTile = town.getMapValue(iTileX, iTileY);
			if (iCurrentTile == 0) {
				if (rand() % 4 == 3) {
					town.setAndRedrawMapValueAt(iTileX, iTileY, 3, eng_for_print, eng_for_print->getBackgroundSurface());
					eng_for_print->townmap[iTileY][iTileX] = 3;
				}else {
					town.setAndRedrawMapValueAt(iTileX, iTileY, 2, eng_for_print, eng_for_print->getBackgroundSurface());
					eng_for_print->townmap[iTileY][iTileX] = 2;
				}
			}
			iCurrentTile = town.getMapValue(iTileX, iTileY);
			if (iCurrentTile == 3) {
				e->change_stratgy(e->STAY);
				//if other enemy is stay in the block, then this one will move randomly
				for (Enemy* en : eng_for_print->enemys) {
					if (en == e)
						continue;
					int jTileX = town.getMapXForScreenX(en->getmidpointX());
					int jTileY = town.getMapYForScreenY(en->getmidpointY());
					if(iTileX == jTileX && iTileY == jTileY)
						e->change_stratgy(e->RANDOM);
				}
			}

			int xdis = eng_for_print->player->getmidpointX() - e->getmidpointX();
			int ydis = eng_for_print->player->getmidpointY() - e->getmidpointY();
			double distance = sqrt(xdis * xdis + ydis * ydis);

			int iplayerTileX = town.getMapXForScreenX(eng_for_print->player->getmidpointX());
			int iplayerTileY = town.getMapYForScreenY(eng_for_print->player->getmidpointY());
			int iplayerCurrentTile = town.getMapValue(iplayerTileX, iplayerTileY);
			if (iplayerCurrentTile != 4) {
				if (distance <= 250) {
					e->change_stratgy(e->TOWORDSPLAYER);
				}
				else {
					if (e->get_stratgy() != e->STAY || iCurrentTile != 3)
						e->change_stratgy(e->RANDOM);
				}
			}
			else{
				if (distance <= 400) {
					e->change_stratgy(e->TOWORDSPLAYER);
				}
				else {
					if (e->get_stratgy() != e->STAY || iCurrentTile != 3)
						e->change_stratgy(e->RANDOM);
				}
			}
		}

	}
	Bullet* b;
	for (int i = 0;i < eng_for_print->bullets.size();) {
		b = eng_for_print->bullets[i];
		if (b->done) {
			eng_for_print->bullets.erase(eng_for_print->bullets.begin()+i);
			delete b;
			continue;
		}
		i++;
	}

	Enemy* e;
	for (int i = 0; i < eng_for_print->enemys.size();) {
		e = eng_for_print->enemys[i];
		if (e->dead) {
			eng_for_print->enemys.erase(eng_for_print->enemys.begin() + i);
			delete e;
			continue;
		}
		i++;
	}
	{
		int iTileX = town.getMapXForScreenX(eng_for_print->player->getmidpointX());
		int iTileY = town.getMapYForScreenY(eng_for_print->player->getmidpointY());
		int iCurrentTile = town.getMapValue(iTileX, iTileY);
		bool same_block = false;
		for (Enemy* e : eng_for_print->enemys) {
			int iex = town.getMapXForScreenX(e->getmidpointX());
			int iey = town.getMapYForScreenY(e->getmidpointY());
			if (iex == iTileX && iey == iTileY) {
				same_block = true;
			}
		}
		
		if (iCurrentTile == 3) {
			if (!same_block) {
				town.setAndRedrawMapValueAt(iTileX, iTileY, 0, eng_for_print, eng_for_print->getBackgroundSurface());
				eng_for_print->player->incscore();
				eng_for_print->townmap[iTileY][iTileX] = 0;
			}
		}
		if (iCurrentTile == 2) {
			if (!same_block) {
				town.setAndRedrawMapValueAt(iTileX, iTileY, 0, eng_for_print, eng_for_print->getBackgroundSurface());
				eng_for_print->player->dechp();
				eng_for_print->townmap[iTileY][iTileX] = 0;
			}
		}
		if (iCurrentTile == 4) {
			eng_for_print->player->incscore(1);
			for(int i = 0;i < 15;i++)
				for (int j = 0; j < 7; j++) {
					if (town.getMapValue(i, j) == 3 || town.getMapValue(i, j) == 2)
						if (rand() % 350 == 0) {
							town.setAndRedrawMapValueAt(i, j, 0, eng_for_print, eng_for_print->getBackgroundSurface());
							eng_for_print->townmap[j][i] = 0;
						}
				}
		}
	}
	if ((eng_for_print->getRawTime() % 400 ) < 4) {
		cout << "enemy form" << endl;
		Enemy* enemy = new Enemy(eng_for_print,220,20);
		enemy->initilize();
		eng_for_print->appendObjectToArray(enemy);
		eng_for_print->enemys.push_back(enemy);
	};

	if (!(eng_for_print->player->isalive())) {
		//turn to quit menu
		Charactordatas<bool>::save_highest_score(eng_for_print->player->getscore());
		context_->TransitionTo(new Gameend(this->eng_for_print));
	}
}



