#include "header.h"
#include "Loading_page.h"
#include "ExplorerEngine.h"
#include "Town_state.h"
#include "Pause_menu.h"
#include "Startmenu.h"

void Loading_page::key_pressed(int iKeycode) {
	if (iKeycode == SDLK_p) {
		pages++;
		pages %= 3;
	}
	if (iKeycode == SDLK_b) {
		if(from == START_MENU)
			context_->TransitionTo(new Startmenu(this->eng_for_print));
		else {
			SimpleImage image = ImageManager::loadImage("images/pause_bg.jpg", false);
			image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
				0, 0,
				eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
				0, 0,
				image.getWidth(), image.getHeight(), false);
			context_->TransitionTo(new Pause_menu(this->eng_for_print));
		}
	}
	if (iKeycode == SDLK_1 || iKeycode == SDLK_2 || iKeycode == SDLK_3) {
		load_game(iKeycode - SDLK_1);
	}
}

void Loading_page::print_foreground() {
	int color = 0xff0000;
	eng_for_print->drawForegroundString(0, 0, "Load", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
	eng_for_print->drawForegroundString(300, 150, "Slot1_:", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(300, 300, "Slot2_:", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(300, 450, "Slot3_:", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(500, 550, "P_age:", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(1200, 0, "B_ack", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));

	pages == 0 ?
		eng_for_print->drawForegroundString(600, 550, "1", color, eng_for_print->getFont("Myfont.ttf", 40)) :
		eng_for_print->drawForegroundString(600, 550, "1", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));

	pages == 1 ?
		eng_for_print->drawForegroundString(700, 550, "2", color, eng_for_print->getFont("Myfont.ttf", 40)) :
		eng_for_print->drawForegroundString(700, 550, "2", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));

	pages == 2 ?
		eng_for_print->drawForegroundString(800, 550, "3", color, eng_for_print->getFont("Myfont.ttf", 40)) :
		eng_for_print->drawForegroundString(800, 550, "3", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	draw_slot_info();
}

void Loading_page::load_game(int iSlot)
{
	vector<int> playerdata = Charactordatas<int>::load_player(pages, iSlot);
	if (playerdata.size() != 0) {
		for (Bullet* b : eng_for_print->bullets) {
			eng_for_print->removeDisplayableObject(b);
			delete b;
		}
		for (Enemy* e : eng_for_print->enemys) {
			eng_for_print->removeDisplayableObject(e);
			delete e;
		}
		eng_for_print->bullets.clear();
		eng_for_print->enemys.clear();
		
		this->eng_for_print->player->load(playerdata);
		this->eng_for_print->load_bullets(pages,iSlot);
		this->eng_for_print->load_enemys(pages, iSlot);
		this->eng_for_print->townmap = Charactordatas<int>::load_map(pages, iSlot);
		this->eng_for_print->player->setname(Charactordatas<string>::player_name(pages, iSlot));
		this->context_->TransitionTo(new Town_state(eng_for_print));
	}else {
		std::cout << "null file\n";
	}
}

void Loading_page::draw_slot_info() {

	int i = 15 * pages, term = i + 15;
	int ypos = 100;
	int slotpos = 300;
	for (; i < term; i++) {
		switch (i % 5)
		{
		case(1):
		case(2):
		case(3):
			eng_for_print->drawForegroundString(420, ypos, positions[i].c_str(), 0xffffff, eng_for_print->getFont("Myfont.ttf", 30));
			ypos += 30;
			break;
		case(4):
			eng_for_print->drawForegroundString(420, ypos, positions[i].c_str(), 0xffffff, eng_for_print->getFont("Myfont.ttf", 30));
			ypos = slotpos - 50;
			slotpos += 150;
			break;
		default:
			break;
		}
	}
}

