#pragma once
#include "Base_state.h"

class Charactor_creation_gender : public BaseState {
public:
	Charactor_creation_gender(ExplorerEngine* game_engine) :
		BaseState(game_engine) {}

	virtual void print_background() override;
	virtual void print_foreground() override;
	virtual void key_pressed(int iKeycode) override;
};