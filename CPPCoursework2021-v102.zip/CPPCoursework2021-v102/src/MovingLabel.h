#pragma once
#include "DisplayableObject.h"
#include "Psyyl10TileManager.h"

class MovingLabel :
    public DisplayableObject
{
public:
    MovingLabel(BaseEngine* pEngine, Psyyl10TileManager* pTileManager, int posX = 0, int posY = 0, int radius = 100)
        :DisplayableObject(pEngine),
        tm(pTileManager)
    {
        m_iCurrentScreenX = posX; // Starting position on the screen
        m_iCurrentScreenY = posY;
        m_iDrawWidth = radius; // Width of drawing area
        m_iDrawHeight = radius; // Height of drawing area
    }
    void virtDraw();
    void virtDoUpdate(int iCurrentTime);
    void setLoc(int iX,int iY);
private:
    Psyyl10TileManager* tm;
    int last_modified = 0;
};

