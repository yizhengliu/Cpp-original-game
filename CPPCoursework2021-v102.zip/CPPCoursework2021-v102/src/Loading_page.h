#pragma once
#include "Base_state.h"
#include "Charactordatas.h"

using namespace std;

class Loading_page : public BaseState {
public:
	Loading_page(ExplorerEngine* game_engine, int f = 0) :
		BaseState(game_engine),
		from(f)
	{
	}

	virtual void key_pressed(int iKeycode) override;

	virtual void print_foreground() override;

	int const START_MENU = 0;
	int const PAUSE_MENU = 1;
private:
	void load_game(int iSlot);
	int from;
	void draw_slot_info();
	int pages = 0;
	vector<string> positions = Charactordatas<string>::load_informations();
};