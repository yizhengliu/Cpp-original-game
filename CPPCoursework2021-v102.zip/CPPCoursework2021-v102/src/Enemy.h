#pragma once
#include "Shootable_object.h"
#include "ImageManager.h"

class Enemy
	:public Shootable_object
{
public:
	Enemy(ExplorerEngine* pEngine, int posX, int posY);

	const int FRONT = 0;
	const int BEHIND = 1;
	const int LEFT = 2;
	const int RIGHT = 3;
	const int RANDOM = 0;
	const int TOWORDSPLAYER = 1;
	const int STAY = 2;
	virtual void virtDraw() override;
	virtual void virtDoUpdate(int iCurrentTime) override;
	void initilize();
	int state = 0;
	bool dead = false;
	void change_stratgy(int new_str) { moving_stratgy = new_str; }
	int get_stratgy() { return moving_stratgy; }
	int getmidpointX() { return m_iCurrentScreenX + (m_iDrawWidth / 2); }
	int getmidpointY() { return m_iCurrentScreenY + (m_iDrawHeight / 2); }
private:
	SimpleImage images[8] = {
		ImageManager::loadImage("images/maoyufront1.png", true),
		ImageManager::loadImage("images/maoyufront2.png", true),
		ImageManager::loadImage("images/maoyubehind1.png", true),
		ImageManager::loadImage("images/maoyubehind1.png", true),
		ImageManager::loadImage("images/maoyuleft1.png", true),
		ImageManager::loadImage("images/maoyuleft2.png", true),
		ImageManager::loadImage("images/maoyuright1.png", true),
		ImageManager::loadImage("images/maoyuright2.png", true)
	};
	void random_moving(int iCurrentTime);
	void moving_towards(int iCurrentTime);
	void stay(int iCurrentTime);
	void front();
	void behind();
	void left();
	void right();
	int damamge = 20;
	int past_time = 0;
	int Xspeed = 0;
	int Yspeed = 2;
	ExplorerEngine* eng_for_print;
	int moving_stratgy = 0;
	int ts = 0;
};