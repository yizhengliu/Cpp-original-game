#include "header.h"
#include "Bullet.h"
#include "BaseEngine.h"

void Bullet::virtDraw(){
	if (isVisible()) {
		charactor.setTransparencyColour(charactor.getPixelColour(0, 0));
		charactor.renderImageApplyingMapping(this->getEngine(),
			this->getEngine()->getForegroundSurface(),
			m_iCurrentScreenX, m_iCurrentScreenY,
			charactor.getWidth(), charactor.getHeight(),
			this->rotator);
	}
}

void Bullet::virtDoUpdate(int iCurrentTime){
	if (isVisible()) {
		m_iCurrentScreenX += Xspeed;
		m_iCurrentScreenY += Yspeed;

		if (m_iCurrentScreenX < -m_iDrawWidth ||
			m_iCurrentScreenX >= getEngine()->getWindowWidth() ||
			m_iCurrentScreenY < -m_iDrawHeight ||
			m_iCurrentScreenY >= getEngine()->getWindowHeight()) {
			getEngine()->removeDisplayableObject(this);
			done = true;
		}

		// Ensure that the objects get redrawn on the display
		redrawDisplay();
	}
}

