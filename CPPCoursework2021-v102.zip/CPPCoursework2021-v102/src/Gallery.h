#pragma once
#include "Base_state.h"
#include "SimpleImage.h"
#include "ImageManager.h"
#include "DrawingSurface.h"

class Gallery : public BaseState {
public:
	Gallery(ExplorerEngine* game_engine);

	~Gallery() {
		rescale();
	}
	virtual void do_before_loop() override;
	virtual void mousewheel_moved(int x, int y, int which, int timestamp) override;
	virtual void print_background() override;
	virtual void print_foreground() override;
	virtual void key_pressed(int iKeycode) override;
private:
	void rescale();
	int m_iCurrentSurfaceNumber = 1;
	int stretchtimes = 0;
	DrawingSurface m_oTheExtraSurface1;
	DrawingSurface m_oTheExtraSurface2;
	DrawingSurface m_oTheExtraSurface3;
	DrawingSurface m_oTheExtraSurface4;
	SimpleImage images[15] = {
		ImageManager::loadImage("marisafront.png", true),
		ImageManager::loadImage("marisabehind.png", true),
		ImageManager::loadImage("marisaleft.png", true),
		ImageManager::loadImage("marisaright.png",true),

		ImageManager::loadImage("hetongfront.png", true),
		ImageManager::loadImage("hetongbehind.png", true),
		ImageManager::loadImage("hetongleft.png", true),
		ImageManager::loadImage("hetongright.png",true),

		ImageManager::loadImage("bullets_player.png", true),
		ImageManager::loadImage("bullets_enemy.png", true),
		ImageManager::loadImage("grass.png", true),

		ImageManager::loadImage("1.jpg", true),
		ImageManager::loadImage("2.jpg", true),
		ImageManager::loadImage("3.jpg", true),
		ImageManager::loadImage("4.jpg", true),
	};
};