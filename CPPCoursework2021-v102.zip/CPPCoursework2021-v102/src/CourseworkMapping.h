#pragma once
#include "ImagePixelMapping.h"
#include "ImageManager.h"

class CourseworkMapping :
    public ImagePixelMappingRotate
{
public:
    CourseworkMapping(double r, int ixOffset = 0, int iyOffset = 0)
        :ImagePixelMappingRotate(r),
        xOffset(ixOffset),
        yOffset(iyOffset){
        SimpleImage charactor = ImageManager::loadImage("bullets_player.png", true);
        c = charactor.getPixelColour(0, 0);
    }

    virtual bool mapCoordinates(double& x, double& y, const SimpleImage& image)
  {
        if (x < 0) return false;
        if (y < 0) return false;
        if (x >= (image.getWidth() - 0.5)) return false;
        if (y >= (image.getHeight() - 0.5)) return false;

        x += xOffset;
        y += yOffset;

        while (x > image.getWidth())
            x -= image.getWidth();
        while (x < 0)
            x += image.getWidth();
        while (y > image.getHeight())
            y -= image.getHeight();
        while (y < 0)
            y += image.getHeight();

        // Shift offset to the centre of the image, so we can rotate around centre
        x -= image.getWidth() / 2;
        y -= image.getHeight() / 2;

        // Rotate it
        double dAngle = atan(y / (x + 0.0001));
        if (x < 0)
            dAngle += M_PI;
        double hyp = ::sqrt(x * x + y * y);
        dAngle += (double)rotation;

        x = hyp * ::cos(dAngle);
        y = hyp * ::sin(dAngle);

        // Shift offset back to the corner
        x += image.getWidth() / 2;
        y += image.getHeight() / 2;

        
        if (x < 0) return false;
        if (y < 0) return false;
        if (x >= (image.getWidth() - 0.5)) return false;
        if (y >= (image.getHeight() - 0.5)) return false;

        return true;
    }

    virtual bool changePixelColour(int x, int y, int& colour, DrawingSurface* pTarget) {
        if (colour == c)
            return false;
        brightness = rand() % 101;
        // Alter brightness of RGB separately by the specified amount
        double dR = ((0xFF & (colour >> 16)) * brightness) / 100.0;
        double dG = ((0xFF & (colour >> 8)) * brightness) / 100.0;
        double dB = ((0xFF & colour) * brightness) / 100.0;

        // Catch saturation - should never happen, but just in case of rounding issues...
        if (dR > 255) dR = 255;
        if (dG > 255) dG = 255;
        if (dB > 255) dB = 255;

        colour = ((((int)(dR + 0.5)) & 0xFF) << 16)
            + ((((int)(dG + 0.5)) & 0xFF) << 8)
            + ((((int)(dB + 0.5)) & 0xFF));
        return true;
    }
private:
    int c;
    double brightness = 0;
    int xOffset;
    int yOffset;
};

