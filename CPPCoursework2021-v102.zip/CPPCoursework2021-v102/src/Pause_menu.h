#pragma once
#include "Base_state.h"

class Pause_menu : public BaseState {
public:
	Pause_menu(ExplorerEngine* game_engine) :
		BaseState(game_engine) {
	}

	virtual void key_pressed(int iKeycode) override;

	virtual void print_foreground() override;
};