#pragma once
#include "Base_state.h"
#include "SimpleImage.h"
#include "ImageManager.h"
class Startmenu : public BaseState {
public:
	Startmenu(ExplorerEngine* game_engine) :
		BaseState(game_engine){
		initilize();
	}
	virtual void print_foreground() override;

	virtual void print_background() override;

	virtual void mouse_pressed(int iButton, int iX, int iY) override;

	virtual void key_pressed(int iKeycode) override;
private:
	void initilize();
	//int ini = 0;
	int Offset = 0;
	//SimpleImage bg = ImageManager::loadImage("background.jpg", true);
};