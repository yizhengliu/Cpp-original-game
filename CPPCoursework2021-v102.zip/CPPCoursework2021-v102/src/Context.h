#pragma once
#include "Player.h"
#include "Base_state.h"
#include <string>

class Context {
private:
	BaseState* state_;
	bool changed = false;
public:
	string getstatename() {
		if (state_ == nullptr)
			return "";
		return typeid(*state_).name();
	}
	Context(BaseState* state) : state_(nullptr) {
		this->TransitionTo(state);
	}
	~Context() {
		delete state_;
	}

	void TransitionTo(BaseState* state) {
		std::cout << "Context: Transition to " << typeid(*state).name() << ".\n";
		if (this->state_ != nullptr)
			delete this->state_;
		this->state_ = state;
		this->state_->set_context(this);
		changed = true;
	}

	bool check_state_changed() {
		if (changed) {
			changed = false;
			return true;
		}
		return false;
	}
	void Request_mousewheel(int x, int y, int which, int timestamp) {
		this->state_->mousewheel_moved(x,y,which,timestamp);
	}

	void Request_before_loop() {
		this->state_->do_before_loop();
	}

	void Request_background() {
		this->state_->print_background();
	}
	void Request_foreground() {
		this->state_->print_foreground();
	}
	void Mouse_event(int iButton, int iX, int iY) {
		this->state_->mouse_pressed(iButton, iX, iY);
	}
	void Key_event(int iKeyCode) {
		this->state_->key_pressed(iKeyCode);
	}
};
