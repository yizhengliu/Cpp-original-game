#pragma once
#include "Base_state.h"
#include "Town.h"
#include <vector>
using namespace std;
class Town_state : public BaseState {
public:
	Town_state(ExplorerEngine* game_engine) :
		BaseState(game_engine) {
		initialize();
	}

	virtual void key_pressed(int iKeycode) override;
	virtual void print_foreground() override;
	virtual void mouse_pressed(int iButton, int iX, int iY) override;
	
	virtual void do_before_loop() override;
	~Town_state() {
		unshow_player();
	}
private:
	Town town;
	void initialize();
	void show_player();
	void unshow_player();

};