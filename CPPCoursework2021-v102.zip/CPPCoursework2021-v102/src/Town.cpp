#include "header.h"
#include "Town.h"

void Town::virtDrawTileAt(
	BaseEngine* pEngine, // We don't need this but maybe a student will so it is here to use if needed
	DrawingSurface* pSurface,
	int iMapX, int iMapY,
	int iStartPositionScreenX, int iStartPositionScreenY) const
{
	
	int iMapValue = getMapValue(iMapX, iMapY);
	/*
	images[iMapValue].renderImage(pSurface, 0, 0,
		iStartPositionScreenX, iStartPositionScreenY,
		getTileWidth(), getTileHeight());
		*/
	
	SimpleImage target = images[iMapValue];
	target.renderImageBlit(pEngine, pSurface,
		iStartPositionScreenX, iStartPositionScreenY,
		getTileWidth(), getTileHeight(),
		0, 0,
		target.getWidth(), target.getHeight(),false);
		
}
