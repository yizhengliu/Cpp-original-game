#include "header.h"
#include "Pause_menu.h"
#include "ExplorerEngine.h"
#include "Town_state.h"
#include "Saving_page.h"
#include "Loading_page.h"
#include "Startmenu.h"

void Pause_menu::key_pressed(int iKeycode) {
	if (iKeycode == SDLK_ESCAPE) {context_->TransitionTo(new Town_state(this->eng_for_print));}
	else if (iKeycode == SDLK_q) {eng_for_print->setExitWithCode(0);}
	else if (iKeycode == SDLK_s) {
		SimpleImage image = ImageManager::loadImage("images/loadandsave_bg.jpg", false);
		image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
			0, 0,
			eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
			0, 0,
			image.getWidth(), image.getHeight(), false);
		context_->TransitionTo(new Saving_page(this->eng_for_print)); 
	}
	else if (iKeycode == SDLK_l) {
		SimpleImage image = ImageManager::loadImage("images/loadandsave_bg.jpg", false);
		image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
			0, 0,
			eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
			0, 0,
			image.getWidth(), image.getHeight(), false);
		context_->TransitionTo(new Loading_page(this->eng_for_print, 1));
	}
	else if (iKeycode == SDLK_t) { 
		eng_for_print->player->restart();
		for (Bullet* b : eng_for_print->bullets) {
			eng_for_print->removeDisplayableObject(b);
			delete b;
		}
		for (Enemy* e : eng_for_print->enemys) {
			eng_for_print->removeDisplayableObject(e);
			delete e;
		}
		eng_for_print->bullets.clear();
		eng_for_print->enemys.clear();
		context_->TransitionTo(new Startmenu(this->eng_for_print)); 
	}
}

void Pause_menu::print_foreground() {
	eng_for_print->drawForegroundString(500, 0, "Pause", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
	eng_for_print->drawForegroundString(100, 100, "Q_uit", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(100, 200, "L_oad", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(100, 300, "S_ave", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(100, 400, "Start_Screen", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
}