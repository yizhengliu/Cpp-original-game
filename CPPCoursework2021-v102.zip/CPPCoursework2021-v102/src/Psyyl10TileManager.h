#pragma once
#include "TileManager.h"
class Psyyl10TileManager :
    public TileManager
{

public:
    Psyyl10TileManager()
        : TileManager(30,30,6,9)
    {
    }
public:
    virtual void virtDrawTileAt(
        BaseEngine* pEngine,
        DrawingSurface* pSurface,
        int iMapX, int iMapY,
        int iStartPositionScreenX, int iStartPositionScreenY) const override;

};

