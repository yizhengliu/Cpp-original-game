#include "header.h"
#include "ExplorerEngine.h"
#include <string>
#include "Charactordatas.h"
#include <vector>

void ExplorerEngine::load_bullets(int iPage, int iSlot){
	vector<double> results = Charactordatas<double>::load_bullets(iPage,iSlot);
	for (int i = 0; i < results.size();) {
		int posX = static_cast<int>(results[i++]);
		int posY = static_cast<int>(results[i++]);
		double theta = results[i++];
		Bullet* new_bullet = new Bullet(this, posX, posY, theta);
		bullets.push_back(new_bullet);
	}
	for (Bullet* b : bullets) {
		appendObjectToArray(b);
	}
}

void ExplorerEngine::load_enemys(int iPage, int iSlot){
	vector<int> results = Charactordatas<int>::load_enemys(iPage, iSlot);
	for (int i = 0; i < results.size();) {
		int posX = results[i++];
		int posY = results[i++];
		Enemy* enemy = new Enemy(this,posX,posY);
		enemy->initilize();
		enemys.push_back(enemy);
	}
	for (Enemy* enemy : enemys) {
		appendObjectToArray(enemy);
	}
}

void ExplorerEngine::virtMouseWheel(int x, int y, int which, int timestamp)
{

	context->Request_mousewheel(x, y, which, timestamp);
	// Redraw the background
	redrawDisplay(); // Force total redraw
}

int ExplorerEngine::virtInitialise()
{
	// These only need to be called once, so I didn't want to put them in functions which are called multiple times, even though I now need to override this method too
	//getBackgroundSurface()->setDrawPointsFilter(&m_filterTranslation);
	this->notifyObjectsAboutMouse(true);
	getForegroundSurface()->setDrawPointsFilter(&m_filterTranslation);
	context = new Context(new Startmenu(this));
	// Call base class version
	return BaseEngine::virtInitialise();
}

void ExplorerEngine::virtSetupBackgroundBuffer()
{
	//fillBackground(0xFFFFFF);
	redrawDisplay();
}


void ExplorerEngine::virtMouseDown(int iButton, int iX, int iY)
{	
	context->Mouse_event(iButton,iX,iY);
	if (context->check_state_changed()) {
		lockBackgroundForDrawing();
		lockForegroundForDrawing();
		context->Request_background();
		context->Request_foreground();
		unlockBackgroundForDrawing();
		unlockForegroundForDrawing();
	}
	redrawDisplay();
}


void ExplorerEngine::virtKeyDown(int iKeyCode)
{
	context->Key_event(iKeyCode);

	if (context->check_state_changed()) {
		lockBackgroundForDrawing();
		lockForegroundForDrawing();
		context->Request_background();
		context->Request_foreground();
		unlockBackgroundForDrawing();
		unlockForegroundForDrawing();
	}
	
	redrawDisplay();
}


int ExplorerEngine::virtInitialiseObjects()
{	
	// Record the fact that we are about to change the array
// so it doesn't get used elsewhere without reloading it
	drawableObjectsChanged();
	// Destroy any existing objects
	destroyOldObjects(true);
	// Creates an array big enough for the number of objects that you want.
	createObjectArray(1);
	// You MUST set the array entry after the last one that you create to NULL,
	// so that the system knows when to stop.
	storeObjectInArray(0, player);
	// NOTE: We also need to destroy the objects, but the method at the
	// top of this function will destroy all objects pointed at by the
	// array elements so we can ignore that here.
	setAllObjectsVisible(false);

	return 0;
}

void ExplorerEngine::virtDrawStringsUnderneath() {
	lockBackgroundForDrawing();
	lockForegroundForDrawing();
	context->Request_background();
	unlockBackgroundForDrawing();
	unlockForegroundForDrawing();
	redrawDisplay();
}

void ExplorerEngine::virtDrawStringsOnTop()
{
	lockBackgroundForDrawing();
	lockForegroundForDrawing();
	context->Request_foreground();
	unlockBackgroundForDrawing();
	unlockForegroundForDrawing();
	redrawDisplay();
}

void ExplorerEngine::virtMainLoopDoBeforeUpdate(){
	lockBackgroundForDrawing();
	lockForegroundForDrawing();
	context->Request_before_loop();
	unlockBackgroundForDrawing();
	unlockForegroundForDrawing();
	redrawDisplay();
}

