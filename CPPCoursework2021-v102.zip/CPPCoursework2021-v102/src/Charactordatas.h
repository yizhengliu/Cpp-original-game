#pragma once
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include "Bullet.h"
#include "Enemy.h"
using namespace std;

template <typename T>

class Charactordatas
{
public:
	static vector<T> load_player(int iPage, int iSlot) {
		vector<T> player_info;
		int startpos = iPage * 15 + 5 * iSlot;
		ifstream infos(getplayerfilename(startpos).c_str());
		T info;
		string flag;
		while (infos) {
			if (!(infos >> info)) {
				infos.clear();
				getline(infos, flag);
			}else {
				player_info.push_back(info);
			}
		}
		infos.close();
		return player_info;
	}
	static vector<vector<T>> load_map(int iPage, int iSlot) {
		int startpos = iPage * 15 + 5 * iSlot;
		string player_filename = getplayerfilename(startpos);
		string plain_name = player_filename.erase(player_filename.find(".dat"), 4);
		plain_name += "_map.dat";
		vector<vector<T>> result;
		T data;
		ifstream file_for_reading(plain_name.c_str());
		for (int i = 0; i < 7; i++) {
			vector<T> row;
			for (int j = 0; j < 15; j++) {
				file_for_reading >> data;
				row.push_back(data);
			}
			result.push_back(row);
		}
		file_for_reading.close();
		return result;
	}

	static void save_map(vector<vector<int>> score,string filename) {
		ofstream map_file(filename);
		for (int i = 0; i < 7; i++)
			for (int j = 0; j < 15; j++)	
				map_file << score[i][j] << endl;
		map_file.close();
	}

	static T load_highest_score() {
		T data;
		ifstream file_for_reading("highest_score.dat");
		file_for_reading >> data;
		file_for_reading.close();
		return data;
	}

	static void save_highest_score(int score) {
		if (check_exist("highest_score.dat"))
			if (score <= Charactordatas<int>::load_highest_score())
				return;
		ofstream score_file("highest_score.dat");
		score_file << score << endl;
		score_file.close();
	}

	static T player_name(int iPage, int iSlot) {
		vector<T> positions = load_informations();
		int startpos = iPage * 15 + 5 * iSlot;
		return convert(positions[startpos + 4]);
	}

	static vector<T> load_informations() {
		if (!check_exist("positions.dat")) {
			initilize_datas();
		}
		ifstream file_for_reading("positions.dat");
		
		vector<T> positions;
		T position;
		while (file_for_reading >> position){
			positions.push_back(position);
		}

		file_for_reading.close();
		return positions;
	}

	static vector<T> load_enemys(int iPage, int iSlot) {
		int startpos = iPage * 15 + 5 * iSlot;
		string player_filename = getplayerfilename(startpos);
		string plain_name = player_filename.erase(player_filename.find(".dat"), 4);
		plain_name += "_enemys.dat";
		ifstream infos(plain_name.c_str());
		vector<T> results;
		T info;
		while (infos >> info) {
			results.push_back(info);
		}
		infos.close();
		return results;
	}

	static vector<T> load_bullets(int iPage, int iSlot) {
		int startpos = iPage * 15 + 5 * iSlot;
		string player_filename = getplayerfilename(startpos);
		string plain_name = player_filename.erase(player_filename.find(".dat"),4);
		plain_name += "_bullets.dat";
		ifstream infos(plain_name.c_str());
		vector<T> results;
		T info;
		while(infos >> info) {
			results.push_back(info);
		}
		infos.close();
		return results;
	}

	static vector<T> save_information(vector<T> data_tosave, int iPage,int iSlot,vector<Bullet*> bullets,vector<Enemy*> enemys,vector<vector<int>> map) {
		string file_name = convert(data_tosave[0]);
		vector<T> positions = load_informations();
		int startpos = iPage*15 + 5*iSlot;
		time_t currenttime = time(&currenttime);
		char str[26];
		ctime_s(str, sizeof str, &currenttime);
		for (char& c : str) {
			if (c == ' ')
				c = '_';
			else if (c == '\n')
				c = '\0';
		}
		string origin_filename = convert(positions[startpos]);
		if (origin_filename != "Null") {
			cout << origin_filename << endl;
			if (remove(origin_filename.c_str()))
				cout << "fail delete" << endl;
			else
				cout << "success delete" << endl;
			string plainname = origin_filename.erase(origin_filename.find(".dat"), 4);
			plainname += "_bullets.dat";
			if (remove(plainname.c_str()))
				cout << "fail delete" << endl;
			else
				cout << "success delete" << endl;
			plainname = origin_filename;
			plainname += "_enemys.dat";
			if (remove(plainname.c_str()))
				cout << "fail delete" << endl;
			else
				cout << "success delete" << endl;
			plainname = origin_filename;
			plainname += "_map.dat";
			if (remove(plainname.c_str()))
				cout << "fail delete" << endl;
			else
				cout << "success delete" << endl;
		}
		while (check_exist(file_name + ".dat")) {
			file_name += ('a' + rand() % 26);
		}
		save_enemys(enemys, file_name + "_enemys.dat");
		save_bullets(bullets, file_name+ "_bullets.dat");
		save_map(map, file_name + "_map.dat");
		positions[startpos] = file_name + ".dat";
		positions[startpos + 2] = str;
		positions[startpos + 4] = convert(data_tosave[0]);
		save_file_with_given_data(positions, "positions.dat");
		save_file_with_given_data(data_tosave, (file_name + ".dat"));
		return positions;
	}
private:
	static string getplayerfilename(int pos) {
		vector<string> positions = Charactordatas<string>::load_informations();
		return positions[pos];
	}

	static void save_bullets(vector<Bullet*> bullets, string file_name) {
		ofstream bullet_file(file_name);
		for (int i = 0; i < bullets.size(); i++) {
			bullet_file << bullets[i]->getcurrentX() << endl;
			bullet_file << bullets[i]->getcurrentY() << endl;
			bullet_file << bullets[i]->getTheta() << endl;
		}
		bullet_file.close();
	}

	static void save_enemys(vector<Enemy*> enemys,string file_name) {
		ofstream enemy_file(file_name);
		for (int i = 0; i < enemys.size(); i++) {
			enemy_file << enemys[i]->getcurrentX() << endl;
			enemy_file << enemys[i]->getcurrentY() << endl;
		}
		enemy_file.close();
	}

	static string convert(T data) {
		return dynamic_cast<string&>(data);
	}

	static void save_file_with_given_data(vector<T> data_tosave,string file_name) {
		ofstream position_file(file_name);
		for (auto s : data_tosave) {
			position_file << s << endl;
		}
		position_file.close();
	}
	
	static bool check_exist(string file_name) {
		ifstream file_for_reading(file_name);
		if (file_for_reading.fail())
			return false;
		file_for_reading.close();
		return true;
	}

	static void initilize_datas() {
		ofstream position_file("positions.dat");
		for (int i = 0; i < 9; i++) {
			position_file << "Null" << endl;
			position_file << "CreationTime:" << endl;
			position_file << "--------------" << endl;
			position_file << "PlayerName:" << endl;
			position_file << "--------------" << endl;
		}
		position_file.close();
	}
};
