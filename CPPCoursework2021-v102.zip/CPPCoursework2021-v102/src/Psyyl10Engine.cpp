#include "header.h"
#include "Psyyl10Engine.h"

void Psyyl10Engine::virtSetupBackgroundBuffer()
{
	//initially white
	fillBackground(0xFFFFFF);
	//fill it with relatively random color,but with some pattern in a 99% chance
	for (int iX = 0; iX < this->getWindowWidth(); iX++) {
		for (int iY = 0; iY < this->getWindowHeight(); iY++) {
			unsigned int iColour = (unsigned int)(((iX * 6)) << 12) // red
				+ (unsigned int)((iY * 6) << 8) // green
				+ (unsigned int)((iX * iY ) << 4); // blue
			if(rand() % 100 != 0)
				setBackgroundPixel(iX, iY, iColour);
		}
	}
	
	SimpleImage image = ImageManager::loadImage("demo2a.png", true);
	image.renderImage(getBackgroundSurface(), 100, 500, 10, 500,
		image.getWidth(), image.getHeight());

	lockBackgroundForDrawing();
	//draw a rectange, left top and right bottom and a color
	drawBackgroundRectangle(800,20, 900, 120, 0xff00ff);
	//draw a circle, left top and right bottom and a color
	drawBackgroundOval(100, 100 ,400,400 ,0x000000);
	//draw a thick lin, left top and right bottom and a color and thickness
	drawBackgroundThickLine(1000, 0, 1000, 500,0x305801, 9);
	//draw a triangle with 3 points and color
	drawBackgroundTriangle(90, 90, 500, 300, 700, 800, 0x123456);
	unlockBackgroundForDrawing();
	redrawDisplay(); // Force background to be redrawn to foreground


	tm.setTopLeftPositionOnScreen(700,400);
	tm.drawAllTiles(this, getBackgroundSurface());
}


void Psyyl10Engine::virtMouseDown(int iButton, int iX, int iY)
{
	printf("Mouse clicked at %d %d\n", iX, iY);
	if (iButton == SDL_BUTTON_LEFT)
	{
		ml1->setLoc(iX,iY);
		pressed_counter++;
	}
	else if (iButton == SDL_BUTTON_RIGHT)
	{
		pressed_counter++;
	}

}


void Psyyl10Engine::virtKeyDown(int iKeyCode)
{
	switch (iKeyCode)
	{
	case ' ': {
		virtInitialiseObjects();
		break; 
	}
	case 'p': {
		if (am1->isstopping)
			am1->restart();
		else
			am1->stop();
		break; 
	}
	}
}


int Psyyl10Engine::virtInitialiseObjects()
{
	// Record the fact that we are about to change the array
// so it doesn't get used elsewhere without reloading it
	drawableObjectsChanged();
	// Destroy any existing objects
	destroyOldObjects(true);
	// Creates an array big enough for the number of objects that you want.
	createObjectArray(2);
	// You MUST set the array entry after the last one that you create to NULL,
	// so that the system knows when to stop.
	ml1 = new MovingLabel(this,&tm);
	am1 = new AutomatedMovingRec(this,&tm);
	storeObjectInArray(0, ml1);
	storeObjectInArray(1, am1);
	// NOTE: We also need to destroy the objects, but the method at the
	// top of this function will destroy all objects pointed at by the
	// array elements so we can ignore that here.
	setAllObjectsVisible(true);
	return 0;
}
void Psyyl10Engine::virtDrawStringsUnderneath() {
	drawBackgroundString(300, 300, "Hello, here is the background text", 0xFFFFFF, NULL);
}

void Psyyl10Engine::virtDrawStringsOnTop()
{
	time_t t;   // not a primitive datatype
	time(&t);

	char buf[128];
	char i;
	int j;	
	sprintf(buf, "Current Time : %s", ctime(&t));
	for (auto& i : buf) {
		if (i == 10)
			i = 0;
	}
	drawForegroundString(300, 200, buf, 0xff0000, NULL);
	
	sprintf(buf, "you have pressed %d times mouse", pressed_counter);
	drawForegroundString(300, 100, buf, 0x00ff00, NULL);
}
