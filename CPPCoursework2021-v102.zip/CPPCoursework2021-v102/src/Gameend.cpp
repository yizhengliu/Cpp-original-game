#include "header.h"
#include "Gameend.h"
#include "ExplorerEngine.h"
#include "Startmenu.h"
#include "Charactordatas.h"

void Gameend::key_pressed(int iKeycode){
	if (iKeycode == SDLK_t) {
		eng_for_print->player->restart();
		for (Bullet* b : eng_for_print->bullets) {
			eng_for_print->removeDisplayableObject(b);
			delete b;
		}
		for (Enemy* e : eng_for_print->enemys) {
			eng_for_print->removeDisplayableObject(e);
			delete e;
		}
		eng_for_print->bullets.clear();
		eng_for_print->enemys.clear();
		context_->TransitionTo(new Startmenu(this->eng_for_print));
	}
}

void Gameend::print_foreground(){
	eng_for_print->drawForegroundLine(580,200,870,200,0xffffff);
	eng_for_print->drawForegroundLine(580, 200, 580, 420, 0xffffff);
	eng_for_print->drawForegroundLine(580,420,870,420, 0xffffff);
	eng_for_print->drawForegroundLine(870,200,870,420, 0xffffff);

	eng_for_print->drawForegroundString(600, 200, "Your Score was:",
		0x000000, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(650, 240, (std::to_string(eng_for_print->player->getscore())).c_str(),
		0xffffff, eng_for_print->getFont("Myfont.ttf", 70));
	eng_for_print->drawForegroundString(600, 310, "Best Score was:",
		0x000000, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(650, 350,Charactordatas<string>::load_highest_score().c_str(),
		0xffffff, eng_for_print->getFont("Myfont.ttf", 70));
	eng_for_print->drawForegroundString(1200, 0, "Start_Screen", 0x000000, eng_for_print->getFont("Myfont.ttf", 40));
}
