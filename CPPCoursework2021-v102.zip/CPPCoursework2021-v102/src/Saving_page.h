#pragma once
#include "Base_state.h"
#include "Charactordatas.h"

using namespace std;

class Saving_page : public BaseState {
public:
	Saving_page(ExplorerEngine* game_engine) :
		BaseState(game_engine) {
	}

	virtual void key_pressed(int iKeycode) override;

	virtual void print_foreground() override;
private:
	void save_game(int iSlot);
	void draw_slot_info();
	int pages = 0;
	vector<string> positions = Charactordatas<string>::load_informations();
};