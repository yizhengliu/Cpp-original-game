#pragma once
#include "BaseEngine.h"
#include "DisplayableObject.h"
#include "SimpleImage.h"
#include "CourseworkMapping.h"
#include "ImageManager.h"
#include "Shootable_object.h"

class Bullet
	:public Shootable_object {
public:
	Bullet(BaseEngine* pEngine, int posX , int posY , int tox, int toy)
		:Shootable_object(pEngine,posX,posY)
	{
		double adj = tox - posX;
		double opp = posY - toy;
		theta = atan2(opp, adj);
		std::cout << theta / M_PI * 180 << std::endl;
		Xspeed = static_cast<int>(SPEED * cos(theta));
		Yspeed = -static_cast <int>(SPEED * sin(theta));
		rotator = new  CourseworkMapping(M_PI / 4 * 3 + theta);
		charactor = ImageManager::loadImage("bullets_player.png", true);
	}
	Bullet(BaseEngine* pEngine, int posX, int posY, double theta) 
		:Shootable_object(pEngine, posX, posY),
		 theta(theta){
		Xspeed = static_cast<int>(SPEED * cos(theta));
		Yspeed = -static_cast <int>(SPEED * sin(theta));
		rotator = new  CourseworkMapping(M_PI / 4 * 3 + theta);
		charactor = ImageManager::loadImage("bullets_player.png", true);
	}
	~Bullet() {
		delete rotator;
	}
	virtual void virtDraw() override;
	virtual void virtDoUpdate(int iCurrentTime) override;
	double getTheta() { return theta; }
	bool done = false;
private:
	const int SPEED = 6;
	double theta;
	int Xspeed;
	int Yspeed;
	CourseworkMapping* rotator;
};