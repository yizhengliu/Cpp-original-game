#include "header.h"
#include "Charactor_creation_name.h"
#include "Charactor_creation_gender.h"
#include "ExplorerEngine.h"

void Charactor_creation_name::print_background() {
	eng_for_print->drawForegroundString(500, 0, "Charactor Creating", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
}
void Charactor_creation_name::print_foreground(){
	eng_for_print->drawForegroundString(350, 60, "please enter your name :", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	char pt[128];
	sprintf(pt, "%s", buf);
	eng_for_print->drawForegroundString(350, 100, pt, 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
	eng_for_print->drawForegroundString(350, 150, "Maximum length : 31", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
}
void Charactor_creation_name::key_pressed(int iKeycode){
	
	if (iKeycode != 13 && iKeycode != 1073741912) {
		if ((iKeycode >= 'a' && iKeycode <= 'z') ||
			(iKeycode >= '0' && iKeycode <= '9') ||
			iKeycode == SDLK_BACKSPACE)
		{
			if (iKeycode == SDLK_BACKSPACE) {
				if (cur > 0)
					buf[--cur] = ' ';
			}
			else {
				if (cur < 31)
					buf[cur++] = (char)iKeycode;
			}
		}
	}
	else {
		for (char& i : buf) {
			if (i == ' ')
				i = 0;
		}
		if (buf[0] == 0) {
			this->eng_for_print->player->setname("anonym");
		}else
			this->eng_for_print->player->setname(buf);
		this->context_->TransitionTo(new Charactor_creation_gender(this->eng_for_print));

	}
}