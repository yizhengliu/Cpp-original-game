#pragma once
#include "TileManager.h"
class MyTileManager :
    public TileManager
{
public:
    MyTileManager()
        : TileManager(35, 35, 15, 15)
    {
    }
public:
    virtual void virtDrawTileAt(
        BaseEngine* pEngine,
        DrawingSurface* pSurface,
        int iMapX, int iMapY,
        int iStartPositionScreenX, int iStartPositionScreenY) const override;

};
