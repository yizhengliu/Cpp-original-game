#pragma once
class ExplorerEngine;
class Context;

class BaseState
{
protected:
	ExplorerEngine* eng_for_print;
	Context* context_ = nullptr;

public:
	BaseState(ExplorerEngine* game_engine)
		:eng_for_print(game_engine)
	{
	}

	virtual ~BaseState() {
	}

	void set_context(Context* context) {
		this->context_ = context;
	}
	virtual void mousewheel_moved(int x, int y, int which, int timestamp) {}
	virtual void do_before_loop() {}
	virtual void print_background() {}
	virtual void print_foreground() {}
	virtual void mouse_pressed(int iButton, int iX, int iY) {}
	virtual void key_pressed(int iKeycode) {}
};
