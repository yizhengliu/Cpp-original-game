#pragma once
#include "BaseEngine.h"
#include "Startmenu.h"
#include "Context.h"
#include "ExampleFilterPointClasses.h" 
#include <vector>
#include "Bullet.h"
#include "Gallery.h"
#include "Enemy.h"
class ExplorerEngine :
    public BaseEngine
{
friend class Startmenu;
friend class Gallery;
public:
    ExplorerEngine()
        : m_filterScaling(0, 0, this),
        m_filterTranslation(0, 0, &m_filterScaling){
    }

    Player* player = new Player(this);
    ~ExplorerEngine() {
        delete context;
    }
    vector<Bullet*> bullets;
    vector<Enemy*> enemys;
    void load_bullets(int iPage,int iSlot);
    void load_enemys(int iPage, int iSlot);
    virtual void virtMouseWheel(int x, int y, int which, int timestamp) override;
    virtual int virtInitialise() override;
    virtual void virtSetupBackgroundBuffer() override;
    virtual void virtMouseDown(int iButton, int iX, int iY) override;
    virtual void virtKeyDown(int iKeyCode) override;
public:
    virtual void virtDrawStringsUnderneath() override;
    virtual int virtInitialiseObjects() override;
    virtual void virtDrawStringsOnTop() override;
    virtual void virtMainLoopDoBeforeUpdate() override;
    vector<vector<int>> townmap
    {
        {0,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,4,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    };
private:
    Context* context;
protected:
    FilterPointsScaling m_filterScaling;
    FilterPointsTranslation m_filterTranslation;
};

