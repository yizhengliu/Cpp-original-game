#include "header.h"
#include "BaseEngine.h"
#include "AutomatedMovingRec.h"
#include "UtilCollisionDetection.h"


void AutomatedMovingRec::virtDraw()
{

	getEngine()->drawForegroundRectangle(
		m_iCurrentScreenX, m_iCurrentScreenY,
		m_iCurrentScreenX + m_iDrawWidth - 1,
		m_iCurrentScreenY + m_iDrawHeight - 1,
		0xFFFFFF);
	getEngine()->drawForegroundString(m_iCurrentScreenX,m_iCurrentScreenY, text.c_str(), 0x000000, NULL);
}

void AutomatedMovingRec::virtDoUpdate(int iCurrentTime)
{
	m_iCurrentScreenX += Xspeed;
	m_iCurrentScreenY += Yspeed;

	DisplayableObject* pObject;
	for (int iObjectId = 0;
		(pObject = getEngine()->getDisplayableObject(iObjectId)
			) != NULL;
		iObjectId++) {
		if (pObject == this) // This is us, skip it
			continue;
		if (pObject == nullptr) // Object does not exist, skip it
			continue;
		if (CollisionDetection::checkRectangles(
			pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(),
			pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom(),
			m_iCurrentScreenX, m_iCurrentScreenX + m_iDrawWidth,
			m_iCurrentScreenY, m_iCurrentScreenY + m_iDrawHeight)) {
			int x,y;
			do {
				x = rand() % getEngine()->getWindowWidth();
				y = rand() % getEngine()->getWindowHeight();
			} while ((x > pObject->getDrawingRegionRight() || 
					 x < pObject->getDrawingRegionLeft() - m_iDrawWidth) &&
					 (y > pObject->getDrawingRegionBottom() ||
						 y < pObject->getDrawingRegionTop() - m_iDrawHeight) );
			m_iCurrentScreenX = x;
			m_iCurrentScreenY = y;

			if (text != "collision")
				text = "collision";
			else
				text = "Automated Rect";
		}
	}
	/*
	if (tm->isValidTilePosition(m_iCurrentScreenX, m_iCurrentScreenY))
	{
		if (iCurrentTime > last_modified + 100)
		{ // Max undates once per 100ms - prevents a lot of updates at once, helping to reduce load
			last_modified = iCurrentTime;
			int iTileX = tm->getMapXForScreenX(m_iCurrentScreenX);
			int iTileY = tm->getMapYForScreenY(m_iCurrentScreenY);
			int iCurrentTile = tm->getMapValue(iTileX, iTileY);
			tm->setAndRedrawMapValueAt(iTileX, iTileY, iCurrentTile, getEngine(), getEngine()->getBackgroundSurface());
		}
	}
	*/
	if (m_iCurrentScreenX < 0) {
		m_iCurrentScreenX = 0;
		Xspeed *= -1;
	}
	if (m_iCurrentScreenX >= getEngine()->getWindowWidth() -
		m_iDrawWidth) {
		m_iCurrentScreenX = getEngine()->getWindowWidth() -
			m_iDrawWidth;
		Xspeed *= -1;
	}
	if (m_iCurrentScreenY < 0) {
		m_iCurrentScreenY = 0;
		Yspeed *= -1;
	}
	if (m_iCurrentScreenY >= getEngine()->getWindowHeight() -
		m_iDrawHeight) {
		m_iCurrentScreenY = getEngine()->getWindowHeight() -
			m_iDrawHeight;
		Yspeed *= -1;
	}
	// Ensure that the objects get redrawn on the display
	redrawDisplay();

}

void AutomatedMovingRec::stop() 
{
	Xspeed = Yspeed = 0;
	isstopping = true;
}

void AutomatedMovingRec::restart() 
{
	Xspeed = Yspeed = 2;
	isstopping = false;
}
