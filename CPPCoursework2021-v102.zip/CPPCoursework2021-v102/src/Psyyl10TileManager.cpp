#include "header.h"
#include "Psyyl10TileManager.h"

void Psyyl10TileManager::virtDrawTileAt(
	BaseEngine* pEngine, // We don't need this but maybe a student will so it is here to use if needed
	DrawingSurface* pSurface,
	int iMapX, int iMapY,
	int iStartPositionScreenX, int iStartPositionScreenY) const
{
	int r = (rand() % 10) + 1;
	unsigned int iColour = (unsigned int)(iMapX * r *91 << 12) // red
		+ (unsigned int)(iMapY * r * 46 << 8) // green
		+ (unsigned int)((iMapX * iMapY * 51) << 4); // blue
#if 0
	if (rand() % 2) {
		pSurface->drawTriangle(
			iStartPositionScreenX, iStartPositionScreenY + getTileHeight() - 1,
			iStartPositionScreenX + getTileWidth() - 1, iStartPositionScreenY + getTileHeight() - 1,
			(2 * iStartPositionScreenX + getTileWidth() - 1) / 2, iStartPositionScreenY,
			iColour);
	}
	else {
		pSurface->drawTriangle(
			iStartPositionScreenX, (2 * iStartPositionScreenY + getTileHeight() - 1) / 2,
			iStartPositionScreenX + getTileWidth() - 1, iStartPositionScreenY,
			iStartPositionScreenX + getTileWidth() - 1, iStartPositionScreenY + getTileHeight() - 1,
			iColour);
	}
#else
	pSurface->drawTriangle(
		iStartPositionScreenX, iStartPositionScreenY + getTileHeight() - 1,
		iStartPositionScreenX + getTileWidth() - 1, iStartPositionScreenY + getTileHeight() - 1,
		(2 * iStartPositionScreenX + getTileWidth() - 1) / 2, iStartPositionScreenY,
		iColour);
#endif
	/*
	pSurface->drawOval(
		iStartPositionScreenX, // Left
		iStartPositionScreenY, // Top
		iStartPositionScreenX + getTileWidth() - 1, // Right
		iStartPositionScreenY + getTileHeight() - 1, // Bottom
		iColour);
	*/
}