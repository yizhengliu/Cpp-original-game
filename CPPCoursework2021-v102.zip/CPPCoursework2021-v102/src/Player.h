#pragma once
#include "ImageManager.h"
#include "Shootable_object.h"
#include "SimpleImage.h"
#include <string>
#include <vector>
using namespace std;

class Player
	:public Shootable_object
{
public:
	Player(ExplorerEngine* pEngine, int posX = 750, int posY = 350);
	void dechp() { hp -= 10; if (hp < 0) alive = false; }
	void incscore(int mode = 0) { 
		if (mode == 0) {
			score += 10;
			checking();
		}else {
			ss += 0.01;
			if (ss >= 1) {
				ss--;
				score++;
				checking();
			}
		}
		
	}
	int getscore() { return score; }
	int gethp() { return hp; }
	int getmp() { return mp; }
	vector<string> playerdatas();
	int getgender() { return sex; }
	void setgender(int newgender) { sex = newgender; }
	string getname() const { return name; }
	void setname(string newname) { name = newname; }
	virtual void virtDraw() override;
	virtual void virtDoUpdate(int iCurrentTime) override;
	virtual void shoot(ExplorerEngine* eng, int fromX, int fromY, int toX, int toY) override;
	const int FEMALE = 0;
	const int MALE = 1;
	void initilize();
	void load(vector<int> datas);
	void enemy_encounte(int state);
	bool isalive() { return alive; }
	void restart();
	int getmidpointX() { return m_iCurrentScreenX + (m_iDrawWidth / 2); }
	int getmidpointY() { return m_iCurrentScreenY + (m_iDrawHeight / 2); } 
private:
	SimpleImage images[32] = {
		ImageManager::loadImage("images/hetongfront1.png", true),
		ImageManager::loadImage("images/hetongfront2.png", true),
		ImageManager::loadImage("images/hetongfront3.png", true),
		ImageManager::loadImage("images/hetongfront2.png", true),
		ImageManager::loadImage("images/hetongbehind1.png", true),
		ImageManager::loadImage("images/hetongbehind2.png", true),
		ImageManager::loadImage("images/hetongbehind3.png", true),
		ImageManager::loadImage("images/hetongbehind2.png", true),
		ImageManager::loadImage("images/hetongleft1.png", true),
		ImageManager::loadImage("images/hetongleft2.png", true),
		ImageManager::loadImage("images/hetongleft3.png", true),
		ImageManager::loadImage("images/hetongleft2.png", true),
		ImageManager::loadImage("images/hetongright1.png", true),
		ImageManager::loadImage("images/hetongright2.png", true),
		ImageManager::loadImage("images/hetongright3.png", true),
		ImageManager::loadImage("images/hetongright2.png", true),

		ImageManager::loadImage("images/marisafront1.png", true),
		ImageManager::loadImage("images/marisafront2.png", true),
		ImageManager::loadImage("images/marisafront3.png", true),
		ImageManager::loadImage("images/marisafront2.png", true),
		ImageManager::loadImage("images/marisabehind1.png", true),
		ImageManager::loadImage("images/marisabehind2.png", true),
		ImageManager::loadImage("images/marisabehind3.png", true),
		ImageManager::loadImage("images/marisabehind2.png", true),
		ImageManager::loadImage("images/marisaleft1.png", true),
		ImageManager::loadImage("images/marisaleft2.png", true),
		ImageManager::loadImage("images/marisaleft3.png", true),
		ImageManager::loadImage("images/marisaleft2.png", true),
		ImageManager::loadImage("images/marisaright1.png", true),
		ImageManager::loadImage("images/marisaright2.png", true),
		ImageManager::loadImage("images/marisaright3.png", true),
		ImageManager::loadImage("images/marisaright2.png", true)
	};
	int sex = -1;
	void front();
	void behind();
	void left();
	void right();
	void checking();
	string name = "";
	int exp = 0;
	int mp = 20;
	int hp = 100;
	int damage = 10;
	int level = 1;
	int score = 0;
	int past_time = 0;
	bool alive = true;
	double ss = 0;
	int ts = 0;
};

