#include "header.h"
#include "Startmenu.h"
#include "Charactor_creation_confirmation.h"
#include "ExplorerEngine.h"
#include "Town_state.h"

void Charactor_creation_confirmation::print_background() {
	eng_for_print->drawForegroundString(500, 0, "Charactor Creating", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
	eng_for_print->drawForegroundString(350, 60, "Player name :", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(350, 100, eng_for_print->player->getname().c_str(), 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
	eng_for_print->drawForegroundString(350, 150, "Playerr Gender :", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	if (eng_for_print->player->getgender() == eng_for_print->player->MALE)
		eng_for_print->drawForegroundString(350, 190, "Male", 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
	else if (eng_for_print->player->getgender() == eng_for_print->player->FEMALE)
		eng_for_print->drawForegroundString(350, 190, "Female", 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
}
void Charactor_creation_confirmation::print_foreground() {
	eng_for_print->drawForegroundString(350, 600, "are you sure to create this charactor ?", 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
	eng_for_print->drawForegroundString(350, 650, "'y' for yes,'n' then return to the start menu", 0xffffff, eng_for_print->getFont("Myfont.ttf", 30));
}
void Charactor_creation_confirmation::key_pressed(int iKeycode){
	if (iKeycode == 'y') {
		vector<vector<int>> map
		{
			{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,4,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		};
		eng_for_print->townmap = map;
		this->context_->TransitionTo(new Town_state(this->eng_for_print));
	}
	else if (iKeycode == 'n') {
		this->context_->TransitionTo(new Startmenu(this->eng_for_print));
	}
}