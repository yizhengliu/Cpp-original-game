#include "header.h"
#include "Gallery.h"
#include "Startmenu.h"
#include "ExplorerEngine.h"

Gallery::Gallery(ExplorerEngine* game_engine) :
	BaseState(game_engine),
	m_oTheExtraSurface1(game_engine),
	m_oTheExtraSurface2(game_engine),
	m_oTheExtraSurface3(game_engine),
	m_oTheExtraSurface4(game_engine){
	eng_for_print->m_iDefaultUpdatePeriod = 1000;
	m_oTheExtraSurface1.createSurface(eng_for_print->m_iWindowWidth, eng_for_print->m_iWindowHeight);
	m_oTheExtraSurface2.createSurface(eng_for_print->m_iWindowWidth, eng_for_print->m_iWindowHeight);
	m_oTheExtraSurface3.createSurface(eng_for_print->m_iWindowWidth, eng_for_print->m_iWindowHeight);
	m_oTheExtraSurface4.createSurface(eng_for_print->m_iWindowWidth, eng_for_print->m_iWindowHeight);

	images[11].renderImageBlit(this->eng_for_print, &m_oTheExtraSurface1,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		images[11].getWidth(), images[11].getHeight(),false);
	images[12].renderImageBlit(this->eng_for_print, &m_oTheExtraSurface2,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		images[12].getWidth(), images[12].getHeight(), false);
	images[13].renderImageBlit(this->eng_for_print, &m_oTheExtraSurface3,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		images[13].getWidth(), images[13].getHeight(), false);
	images[14].renderImageBlit(this->eng_for_print, &m_oTheExtraSurface4,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		images[14].getWidth(), images[14].getHeight(), false);
}

void Gallery::do_before_loop(){
	m_iCurrentSurfaceNumber = (m_iCurrentSurfaceNumber + 1) % 5;
}

void Gallery::mousewheel_moved(int x, int y, int which, int timestamp){
	int iOldCentreX = eng_for_print->convertClickedToVirtualPixelXPosition(eng_for_print->getWindowWidth() / 2);
	int iOldCentreY = eng_for_print->convertClickedToVirtualPixelYPosition(eng_for_print->getWindowHeight() / 2);

	if (y < 0) {
		eng_for_print->m_filterScaling.compress();
		stretchtimes--;
	}
	else if (y > 0) {
		eng_for_print->m_filterScaling.stretch();
		stretchtimes++;
	}
	// Now we grab the position after the zoom
	int iNewCentreX = eng_for_print->convertClickedToVirtualPixelXPosition(eng_for_print->getWindowWidth() / 2);
	int iNewCentreY = eng_for_print->convertClickedToVirtualPixelYPosition(eng_for_print->getWindowHeight() / 2);

	// Apply a translation to offset so it appears to have zoomed on the centre by moving the old centre back to the centre of the screen
	eng_for_print->m_filterTranslation.changeOffset(iNewCentreX - iOldCentreX, iNewCentreY - iOldCentreY);
	// Uncomment the above line to zoom in on centre rather than top left
}

void Gallery::print_background(){
	switch (m_iCurrentSurfaceNumber)
	{
	case 0: eng_for_print->m_pBackgroundSurface = &(eng_for_print->m_oTheBackgroundSurface); break;
	case 1: eng_for_print->m_pBackgroundSurface = &m_oTheExtraSurface1; break;
	case 2: eng_for_print->m_pBackgroundSurface = &m_oTheExtraSurface2; break;
	case 3: eng_for_print->m_pBackgroundSurface = &m_oTheExtraSurface3; break;
	case 4: eng_for_print->m_pBackgroundSurface = &m_oTheExtraSurface4; break;
	}
	m_oTheExtraSurface1.mySDLLockSurface();
	m_oTheExtraSurface2.mySDLLockSurface();
	m_oTheExtraSurface3.mySDLLockSurface();
	m_oTheExtraSurface4.mySDLLockSurface();
	eng_for_print->drawBackgroundString(0, 0, "Gallery", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
    eng_for_print->drawBackgroundString(1200, 0, "B_ack", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
	m_oTheExtraSurface1.mySDLUnlockSurface();
	m_oTheExtraSurface2.mySDLUnlockSurface();
	m_oTheExtraSurface3.mySDLUnlockSurface();
	m_oTheExtraSurface4.mySDLUnlockSurface();
}

void Gallery::print_foreground(){
	int posX = 100;
	int posY = 100;
	int i = 0;
	for (int j = 0;j < 11; j++) {
		SimpleImage& si = images[j];
		si.renderImageWithMask(this->eng_for_print->getForegroundSurface(),
			0,0,
			posX,posY,
			si.getWidth(), si.getHeight());
		posX += 200;
		i++;
		if (i % 4 == 0) {
			posX = 100;
			posY += 200;
		}
	}
}

void Gallery::key_pressed(int iKeycode){
	if (iKeycode == SDLK_b) {
		eng_for_print->fillBackground(0xffffff);
		this->context_->TransitionTo(new Startmenu(this->eng_for_print));
	}
	switch (iKeycode)
	{
	case SDLK_LEFT:
		eng_for_print->m_filterTranslation.changeOffset(20, 0);
		eng_for_print->redrawDisplay();
		break;
	case SDLK_RIGHT:
		eng_for_print->m_filterTranslation.changeOffset(-20, 0);
		eng_for_print->redrawDisplay();
		break;
	case SDLK_UP:
		eng_for_print->m_filterTranslation.changeOffset(0, 20);
		eng_for_print->redrawDisplay();
		break;
	case SDLK_DOWN:
		eng_for_print->m_filterTranslation.changeOffset(0, -20);
		eng_for_print->redrawDisplay();
		break;
	case SDLK_SPACE: // Space moves the top left back to the zero coordinates - to be on initial location
		eng_for_print->m_filterTranslation.setOffset(0, 0);
		eng_for_print->redrawDisplay();
		break;
	}
}

void Gallery::rescale(){
	eng_for_print->m_pBackgroundSurface = &(eng_for_print->m_oTheBackgroundSurface);
	eng_for_print->fillBackground(0xFFFFFF);
	SimpleImage bg = ImageManager::loadImage("background.jpg", true);
	bg.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		bg.getWidth(), bg.getHeight(), false);
	eng_for_print->m_iDefaultUpdatePeriod = 10;
	if (stretchtimes < 0){
		while (stretchtimes++ < 0){
			eng_for_print->m_filterScaling.stretch();
		}
	}else if (stretchtimes > 0) {
		while (stretchtimes-- > 0) {
			eng_for_print->m_filterScaling.compress();
		}
	}
	eng_for_print->m_filterTranslation.setOffset(0, 0);
	eng_for_print->redrawDisplay();
}
