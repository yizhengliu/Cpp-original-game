#pragma once
#include "DisplayableObject.h"
#include "Psyyl10TileManager.h"
class AutomatedMovingRec :
    public DisplayableObject
{
public:
    AutomatedMovingRec(BaseEngine* pEngine, Psyyl10TileManager* pTileManager, int posX = 1000, int posY = 200, int width = 250, int height = 30)
        :DisplayableObject(pEngine),
        tm(pTileManager)
    {
        m_iCurrentScreenX = posX; // Starting position on the screen
        m_iCurrentScreenY = posY;
        m_iDrawWidth = width; // Width of drawing area
        m_iDrawHeight = height; // Height of drawing area
    }
    void virtDraw();
    void virtDoUpdate(int iCurrentTime);
    void stop();
    void restart();
    bool isstopping = false;
private:
    int Xspeed = 2;
    int Yspeed = 2;
    std::string text = "Automated Rect";
    Psyyl10TileManager* tm;
    int last_modified = 0;
};

