#include "header.h"
#include "BaseEngine.h"
#include "MovingLabel.h"
#include "UtilCollisionDetection.h"

void MovingLabel::virtDraw() 
{
	getEngine()->drawForegroundOval(
		m_iCurrentScreenX, m_iCurrentScreenY,
		m_iCurrentScreenX + m_iDrawWidth - 1,
		m_iCurrentScreenY + m_iDrawHeight - 1,
		0x666666);
	
	getEngine()->drawForegroundString(m_iCurrentScreenX ,
		m_iCurrentScreenY + (m_iDrawHeight / 4), "Move me", 0xFFFFFF, NULL);
}

void MovingLabel::virtDoUpdate(int iCurrentTime)
{
	// Change position if player presses a key
	if (getEngine()->isKeyPressed(SDLK_UP) || getEngine()->isKeyPressed(SDLK_w))
		m_iCurrentScreenY -= 2;
	if (getEngine()->isKeyPressed(SDLK_DOWN) || getEngine()->isKeyPressed(SDLK_s))
		m_iCurrentScreenY += 2;
	if (getEngine()->isKeyPressed(SDLK_LEFT) || getEngine()->isKeyPressed(SDLK_a))
		m_iCurrentScreenX -= 2;
	if (getEngine()->isKeyPressed(SDLK_RIGHT) || getEngine()->isKeyPressed(SDLK_d))
		m_iCurrentScreenX += 2;
	if (tm->isValidTilePosition(m_iCurrentScreenX, m_iCurrentScreenY))
	{
		if (iCurrentTime > last_modified + 100)
		{ // Max undates once per 100ms - prevents a lot of updates at once, helping to reduce load
			last_modified = iCurrentTime;
			int iTileX = tm->getMapXForScreenX(m_iCurrentScreenX);
			int iTileY = tm->getMapYForScreenY(m_iCurrentScreenY);
			int iCurrentTile = tm->getMapValue(iTileX, iTileY);
			tm->setAndRedrawMapValueAt(iTileX, iTileY, iCurrentTile, getEngine(), getEngine()->getBackgroundSurface());
		}
	}


	if (m_iCurrentScreenX < 0)
		m_iCurrentScreenX = 0;
	if (m_iCurrentScreenX >= getEngine()->getWindowWidth() -
		m_iDrawWidth)
		m_iCurrentScreenX = getEngine()->getWindowWidth() -
		m_iDrawWidth;
	if (m_iCurrentScreenY < 0)
		m_iCurrentScreenY = 0;
	if (m_iCurrentScreenY >= getEngine()->getWindowHeight() -
		m_iDrawHeight)
		m_iCurrentScreenY = getEngine()->getWindowHeight() -
		m_iDrawHeight;

	// Ensure that the objects get redrawn on the display
	redrawDisplay();

}
void MovingLabel::setLoc(int iX, int iY)
{
	m_iCurrentScreenX = iX;
	m_iCurrentScreenY = iY;
}
