#pragma once
#include "DisplayableObject.h"
#include "SimpleImage.h"
#include "UtilCollisionDetection.h"
class ExplorerEngine;

class Shootable_object
	:public DisplayableObject
{
public:
	Shootable_object(BaseEngine* pEngine, int posX, int posY)
		:DisplayableObject(pEngine)
	{
		m_iCurrentScreenX = posX; // Starting position on the screen
		m_iCurrentScreenY = posY;
	}
	SimpleImage charactor;
	int getcurrentX() { return m_iCurrentScreenX; }
	int getcurrentY() { return m_iCurrentScreenY; }
	int midpointX() { return m_iCurrentScreenX + (charactor.getWidth() / 2); }
	int midpointY() { return m_iCurrentScreenY + (charactor.getHeight() / 2); }
	virtual void shoot(ExplorerEngine* eng,int fromX,int fromY,int toX,int toY) {}
	bool Perfect_Collision_detection(Shootable_object* other, double r = 0, int mode = 0) { 
		int width = this->charactor.getWidth();
		int height = this->charactor.getHeight();
		if (!CollisionDetection::checkRectangles(
			m_iCurrentScreenX, m_iCurrentScreenX+width,
			m_iCurrentScreenY, m_iCurrentScreenY+height,
			other->m_iCurrentScreenX,other->m_iCurrentScreenX+other->charactor.getWidth(),
			other->m_iCurrentScreenY,other->m_iCurrentScreenY+other->charactor.getHeight())) { return false; }
		int this_default_color = this->charactor.getPixelColour(0, 0);
		int other_default_color = other->charactor.getPixelColour(0, 0);
		for (int i = 0; i < width; i++){
			for (int j = 0; j < height; j++){
				int iInA = this->m_iCurrentScreenX + i;
				int jInA = this->m_iCurrentScreenY + j;

				if (iInA < other->m_iCurrentScreenX ||
					iInA > other->m_iCurrentScreenX + other->charactor.getWidth())
					continue;
				if (jInA < other->m_iCurrentScreenY ||
					jInA > other->m_iCurrentScreenY + other->charactor.getHeight())
					continue;
				if (this->charactor.getPixelColour(i, j) ==
					this_default_color)
					continue;
				if (mode == 0) {
					if (other->charactor.getPixelColour(
						iInA - other->m_iCurrentScreenX,
						jInA - other->m_iCurrentScreenY) !=
						other_default_color)
						return true;
				}else {
					r = M_PI / 4 * 3 + r;
					double viInB = iInA - other->m_iCurrentScreenX;
					double vjInB = jInA - other->m_iCurrentScreenY;

					viInB -= other->charactor.getWidth() / 2;
					vjInB -= other->charactor.getHeight() / 2;

					// Rotate it
					double dAngle = atan(vjInB / (viInB + 0.0001));
					if (viInB < 0)
						dAngle += M_PI;
					double hyp = ::sqrt(viInB * viInB + vjInB * vjInB);
					dAngle += (double)r;

					viInB = hyp * ::cos(dAngle);
					vjInB = hyp * ::sin(dAngle);

					// Shift offset back to the corner
					viInB += other->charactor.getWidth() / 2;
					vjInB += other->charactor.getHeight() / 2;

					if (viInB < 0) continue;
					if (vjInB < 0) continue;
					if (viInB >= (other->charactor.getWidth() - 0.5)) continue;
					if (vjInB >= (other->charactor.getHeight() - 0.5)) continue;

					if (other->charactor.getPixelColour(
						static_cast<int>(viInB),
						static_cast<int>(vjInB)) !=
						other_default_color)
						return true;
				}
			}
		}
		return false; 
	}
protected:
	int image_state = 0;
	const int FRONT = 0;
	const int BEHIND = 1;
	const int LEFT = 2;
	const int RIGHT = 3;
};