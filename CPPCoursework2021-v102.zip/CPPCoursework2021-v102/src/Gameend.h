#pragma once
#include "Base_state.h"

class Gameend : public BaseState {
public:
	Gameend(ExplorerEngine* game_engine) :
		BaseState(game_engine) {
	}

	virtual void key_pressed(int iKeycode) override;

	virtual void print_foreground() override;
};