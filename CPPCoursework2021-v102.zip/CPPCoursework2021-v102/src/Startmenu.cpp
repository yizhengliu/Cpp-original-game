#include "header.h"
#include "Startmenu.h"
#include "Charactor_creation_name.h"
#include "ExplorerEngine.h"
#include "Loading_page.h"
#include "Gallery.h"

void Startmenu::print_foreground(){
	eng_for_print->drawForegroundString(550, 100, "Explorer", 0xffffff, eng_for_print->getFont("Myfont.ttf", 100));
	eng_for_print->drawForegroundString(400, 350, "press left mouse button to start new game", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(400, 400, "press right mouse button to load the game", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(400, 450, "press 'g' to view the gallery", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	Offset++;
	Offset %= eng_for_print->getWindowWidth();
}

void Startmenu::print_background() {

	eng_for_print->m_pForegroundSurface->copyRectangleFrom(
		eng_for_print->m_pBackgroundSurface,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		Offset, 0);

	eng_for_print->m_pForegroundSurface->copyRectangleFrom(
		eng_for_print->m_pBackgroundSurface,
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		Offset-eng_for_print->getWindowWidth(), 0);
}

void Startmenu::mouse_pressed(int iButton, int iX, int iY) {
	if (iButton == SDL_BUTTON_LEFT)
	{
		SimpleImage image = ImageManager::loadImage("images/creation_bg.jpg",false);
		image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
			0, 0,
			eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
			0, 0,
			image.getWidth(), image.getHeight(), false);
		//this->eng_for_print->fillBackground(0xFFFFFF);
		this->context_->TransitionTo(new Charactor_creation_name(this->eng_for_print));
	}
	else if (iButton == SDL_BUTTON_RIGHT)
	{
		SimpleImage image = ImageManager::loadImage("images/loadandsave_bg.jpg", false);
		image.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
			0, 0,
			eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
			0, 0,
			image.getWidth(), image.getHeight(), false);
		//this->eng_for_print->fillBackground(0xFFFFFF);
		this->context_->TransitionTo(new Loading_page(this->eng_for_print));
	}
}

void Startmenu::key_pressed(int iKeycode){
	if (iKeycode == SDLK_g) {
		this->context_->TransitionTo(new Gallery(this->eng_for_print));
	}
}

void Startmenu::initilize(){
	SimpleImage bg = ImageManager::loadImage("background.jpg", true);
	bg.renderImageBlit(this->eng_for_print, eng_for_print->getBackgroundSurface(),
		0, 0,
		eng_for_print->getWindowWidth(), eng_for_print->getWindowHeight(),
		0, 0,
		bg.getWidth(), bg.getHeight(), false);
}

