#include "header.h"
#include "Charactor_creation_gender.h"
#include "Charactor_creation_confirmation.h"
#include "ExplorerEngine.h"

void Charactor_creation_gender::print_background()  {
	eng_for_print->drawForegroundString(500, 0, "Charactor Creating", 0xffffff, eng_for_print->getFont("Myfont.ttf", 60));
	eng_for_print->drawForegroundString(350, 60, "Player name :", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(350, 100, this->eng_for_print->player->getname().c_str(), 0xffffff, eng_for_print->getFont("Myfont.ttf", 50));
}
void Charactor_creation_gender::print_foreground() {
	eng_for_print->drawForegroundString(350, 170, "please choose your gender :", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(350, 220, "Male/Female", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));
	eng_for_print->drawForegroundString(350, 260, "Press M for Male, and F for Female", 0xffffff, eng_for_print->getFont("Myfont.ttf", 40));

}
void Charactor_creation_gender::key_pressed(int iKeycode) {
	if (iKeycode == 'm') {
		this->eng_for_print->player->setgender(eng_for_print->player->MALE);
		this->context_->TransitionTo(new Charactor_creation_confirmation(this->eng_for_print));
	}
	else if (iKeycode == 'f') {
		this->eng_for_print->player->setgender(eng_for_print->player->FEMALE);
		this->context_->TransitionTo(new Charactor_creation_confirmation(this->eng_for_print));
	}
}