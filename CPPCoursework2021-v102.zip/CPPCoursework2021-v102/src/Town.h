#pragma once
#include "TileManager.h"
#include "SimpleImage.h"
#include "ImageManager.h"
class Town :
    public TileManager
{
public:
    Town()
        : TileManager(100, 100, 15, 7)
    {
    }

    virtual void virtDrawTileAt(
        BaseEngine* pEngine,
        DrawingSurface* pSurface,
        int iMapX, int iMapY,
        int iStartPositionScreenX, int iStartPositionScreenY) const override;

private:
    SimpleImage images[5] = {
        ImageManager::loadImage("grass.png", true),
        ImageManager::loadImage("enemy_Startpos.png", true),
        ImageManager::loadImage("bonus.png", true),
        ImageManager::loadImage("road.png", true),
        ImageManager::loadImage("stone.png", true)
    };

};

