#include "header.h"
#include "Player.h"
#include "ExplorerEngine.h"

Player::Player(ExplorerEngine* pEngine, int posX, int posY)
	:Shootable_object(pEngine, 750, 350)
{
	m_iCurrentScreenX = posX; // Starting position on the screen
	m_iCurrentScreenY = posY;
}

vector<string> Player::playerdatas()
{
	vector<string> pds;
	pds.push_back(name);
	pds.push_back(to_string(sex));
	pds.push_back(to_string(m_iCurrentScreenX));
	pds.push_back(to_string(m_iCurrentScreenY));
	pds.push_back(to_string(exp));
	pds.push_back(to_string(mp));
	pds.push_back(to_string(hp));
	pds.push_back(to_string(score));
	pds.push_back(to_string(damage));
	pds.push_back(to_string(level));
	return pds;
}

void Player::virtDraw() {
	if (isVisible()) {
		charactor.renderImageWithMask(getEngine()->getForegroundSurface(),
			0, 0, m_iCurrentScreenX, m_iCurrentScreenY,
			m_iDrawWidth, m_iDrawHeight);
	}
}

void Player::virtDoUpdate(int iCurrentTime) {
	if (isVisible()) {
		if (iCurrentTime - past_time > 500) {
			past_time = iCurrentTime;
			checking();
			ts++;
			ts = ts % 4;
			switch (image_state){
			case(1):behind(); break;
			case(0):front(); break;
			case(2):left(); break;
			case(3):right(); break;}
		}
		if (getEngine()->isKeyPressed(SDLK_UP) || getEngine()->isKeyPressed(SDLK_w)) {
			m_iCurrentScreenY -= 2;
			if (image_state != BEHIND) {
				behind();
				image_state = BEHIND;
			}
		}
		if (getEngine()->isKeyPressed(SDLK_DOWN) || getEngine()->isKeyPressed(SDLK_s)) {
			m_iCurrentScreenY += 2;
			if (image_state != FRONT){
				front();
				image_state = FRONT;
			}	
		}
		if (getEngine()->isKeyPressed(SDLK_LEFT) || getEngine()->isKeyPressed(SDLK_a)) {
			m_iCurrentScreenX -= 2;
			if (image_state != LEFT){
				left();
				image_state = LEFT;
			}
		}
		if (getEngine()->isKeyPressed(SDLK_RIGHT) || getEngine()->isKeyPressed(SDLK_d)) {
			m_iCurrentScreenX += 2;
			if (image_state != RIGHT){
				right();
				image_state = RIGHT;
			}
		}

		if (m_iCurrentScreenX < 0)
			m_iCurrentScreenX = 0;
		if (m_iCurrentScreenX >= getEngine()->getWindowWidth() -
			m_iDrawWidth)
			m_iCurrentScreenX = getEngine()->getWindowWidth() -
			m_iDrawWidth;
		if (m_iCurrentScreenY < 0)
			m_iCurrentScreenY = 0;
		if (m_iCurrentScreenY >= getEngine()->getWindowHeight() -
			m_iDrawHeight)
			m_iCurrentScreenY = getEngine()->getWindowHeight() -
			m_iDrawHeight;		

		redrawDisplay();
	}
}

void Player::shoot(ExplorerEngine* eng, int fromX, int fromY, int toX, int toY){
	if (mp >= 5) {
		Bullet* bullet = new Bullet(eng,
			fromX, fromY,
			toX, toY);
		eng->appendObjectToArray(bullet);
		eng->bullets.push_back(bullet);
		mp -= 5;
	}
}

void Player::front() {
	if (sex == FEMALE) {
		charactor = images[16+ts];
	}
	else if (sex == MALE) {
		charactor = images[0+ts];
	}
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
}

void Player::behind() {
	if (sex == FEMALE) {
		charactor = images[20+ts];
	}
	else if (sex == MALE) {
		charactor = images[4+ts];
	}
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
}

void Player::left() {
	if (sex == FEMALE) {
		charactor = images[24+ts];
	}
	else if (sex == MALE) {
		charactor = images[8+ts];
	}
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
}

void Player::right() {
	if (sex == FEMALE) {
		charactor = images[28+ts];
	}
	else if (sex == MALE) {
		charactor = images[12+ts];
	}
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
}

void Player::initilize() {
	front();
}

void Player::load(vector<int> datas)
{
	sex = datas[0];
	m_iCurrentScreenX = datas[1];
	m_iCurrentScreenY = datas[2];
	exp = datas[3];
	mp = datas[4];
	hp = datas[5];
	score = datas[6];
	damage = datas[7];
	level = datas[8];
	for (int i : datas) {
		cout << i << endl;
	}
}

void Player::enemy_encounte(int state) {

	hp -= 20;

	if (hp < 0) {
		alive = false;
		return;
	}

	switch (state)
	{
	case(0):
		m_iCurrentScreenY += 150;
		break;
	case(1):
		m_iCurrentScreenY -= 150;
		break;
	case(2):
		m_iCurrentScreenX -= 150;
		break;
	case(3):
		m_iCurrentScreenX += 150;
		break;
	default:
		break;
	}

	if (m_iCurrentScreenX < 0)
		m_iCurrentScreenX = 0;
	if (m_iCurrentScreenX >= getEngine()->getWindowWidth() -
		m_iDrawWidth)
		m_iCurrentScreenX = getEngine()->getWindowWidth() -
		m_iDrawWidth;
	if (m_iCurrentScreenY < 0)
		m_iCurrentScreenY = 0;
	if (m_iCurrentScreenY >= getEngine()->getWindowHeight() -
		m_iDrawHeight)
		m_iCurrentScreenY = getEngine()->getWindowHeight() -
		m_iDrawHeight;

}

void Player::restart(){
	front();
	m_iCurrentScreenX = 750;
	m_iCurrentScreenY = 350;
	sex = -1;
	name = "";
	exp = 0;
	hp = 100;
	damage = 10;
	level = 1;
	score = 0;
	alive = true;
}

void Player::checking(){
	mp+=2;
	if (mp > 20) mp = 20;
	hp++;
	if (hp > 100) hp = 100;
}
