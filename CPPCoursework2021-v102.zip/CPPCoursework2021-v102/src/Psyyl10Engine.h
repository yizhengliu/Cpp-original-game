#pragma once
#include "BaseEngine.h"
#include "Psyyl10TileManager.h"
#include "MovingLabel.h"
#include "AutomatedMovingRec.h"

class Psyyl10Engine :
    public BaseEngine
{
public:
    void virtSetupBackgroundBuffer() override;
    void virtMouseDown(int iButton, int iX, int iY) override;
    void virtKeyDown(int iKeyCode) override;
protected:
    Psyyl10TileManager tm;
public:
    void virtDrawStringsUnderneath() override;
    int virtInitialiseObjects() override;
    void virtDrawStringsOnTop() override;
private:
    MovingLabel* ml1;
    //MovingLabel* ml2;
    AutomatedMovingRec* am1;
    int pressed_counter = 0;
};

