#include "header.h"
#include "ExplorerEngine.h"
#include "Enemy.h"


Enemy::Enemy(ExplorerEngine* pEngine, int posX, int posY)
	:Shootable_object(pEngine, posX, posY)
{
	eng_for_print = pEngine;
	m_iCurrentScreenX = posX; // Starting position on the screen
	m_iCurrentScreenY = posY;
}

void Enemy::virtDraw(){
	if (isVisible()) {
		charactor.renderImageWithMask(getEngine()->getForegroundSurface(),
			0, 0, m_iCurrentScreenX, m_iCurrentScreenY,
			m_iDrawWidth, m_iDrawHeight);
	}
}

void Enemy::virtDoUpdate(int iCurrentTime){
	if (isVisible()) {
		switch (moving_stratgy) {
		case(0):
			random_moving(iCurrentTime);
			break;
		case(1):
			moving_towards(iCurrentTime);
			break;
		default:
			stay(iCurrentTime);
			break;
		}
		
		m_iCurrentScreenX += Xspeed;
		m_iCurrentScreenY += Yspeed;

		if (m_iCurrentScreenX < 0)
			m_iCurrentScreenX = 0;
		if (m_iCurrentScreenX >= getEngine()->getWindowWidth() -
			m_iDrawWidth)
			m_iCurrentScreenX = getEngine()->getWindowWidth() -
			m_iDrawWidth;
		if (m_iCurrentScreenY < 0)
			m_iCurrentScreenY = 0;
		if (m_iCurrentScreenY >= getEngine()->getWindowHeight() -
			m_iDrawHeight)
			m_iCurrentScreenY = getEngine()->getWindowHeight() -
			m_iDrawHeight;

		redrawDisplay();
	}
}

void Enemy::initilize(){
	front();
}

void Enemy::front(){
	charactor = images[0+ts];
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
	state = FRONT;
}

void Enemy::behind(){
	charactor = images[2 + ts];
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
	state = BEHIND;
}

void Enemy::left(){
	charactor = images[4 + ts];
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
	state = LEFT;
}

void Enemy::right(){
	charactor = images[6 + ts];
	m_iDrawWidth = charactor.getWidth(); // Width of drawing area
	m_iDrawHeight = charactor.getHeight();
	state = RIGHT;
}

void Enemy::random_moving(int iCurrentTime) {
	if (iCurrentTime - past_time > 1000) {
		past_time = iCurrentTime;
		ts++;
		ts %= 2;

		switch (rand() % 4) {
		case(0):
			Xspeed = 2;
			Yspeed = 0;
			break;
		case(1):
			Xspeed = -2;
			Yspeed = 0;
			break;
		case(2):
			Xspeed = 0;
			Yspeed = 2;
			break;
		case(3):
			Xspeed = 0;
			Yspeed = -2;
			break;
		}

		if (Yspeed < 0) {
			behind();
			image_state = BEHIND;
		}
		else if (Yspeed > 0) {
			front();
			image_state = FRONT;
		}
		if (Xspeed < 0) {
			left();
			image_state = LEFT;
		}
		else if (Xspeed > 0) {
			right();
			image_state = RIGHT;
		}
	}
}

void Enemy::moving_towards(int iCurrentTime) {
	if (iCurrentTime - past_time > 1000) {
		past_time = iCurrentTime;
		ts++;
		ts %= 2;
	}
	int playermidX = eng_for_print->player->getmidpointX();
	int playermidY = eng_for_print->player->getmidpointY();
	if (m_iCurrentScreenX < playermidX)
		Xspeed = 2;
	else if (m_iCurrentScreenX == playermidX)
		Xspeed = 0;
	else
		Xspeed = -2;

	if (m_iCurrentScreenY < playermidY)
		Yspeed = 2;
	else if (m_iCurrentScreenY == playermidY)
		Yspeed = 0;
	else
		Yspeed = -2;

	if (Yspeed < 0) {
		behind();
		image_state = BEHIND;
	}
	else if (Yspeed > 0) {
		front();
		image_state = FRONT;
	}
	if (Xspeed < 0) {
		left();
		image_state = LEFT;
	}
	else if (Xspeed > 0) {
		right();
		image_state = RIGHT;
	}

}

void Enemy::stay(int iCurrentTime) {
	if (iCurrentTime - past_time > 1000) {
		past_time = iCurrentTime;
		ts++;
		ts %= 2;
	}

	Xspeed = 0;
	Yspeed = 0;
	switch (image_state) {
	case(1):behind(); break;
	case(0):front(); break;
	case(2):left(); break;
	case(3):right(); break;
	}
}

